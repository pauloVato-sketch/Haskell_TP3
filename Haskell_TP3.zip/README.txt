Integrantes:

Felipe Silva Faria
Paulo Lopes do Nascimento

Obs: Arquivo Utils.hs contém as funções presentes no slide, com algumas outras adicionadas para auxiliar na produção dos códigos.